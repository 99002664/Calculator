#include <stdio.h>
#include <stdlib.h>
#include "test_prime.h"
int main()
{
    test_main();

    return 0;

}
