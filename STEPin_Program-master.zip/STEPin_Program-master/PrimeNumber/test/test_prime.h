#ifndef TEST_PRIME_H_
#define TEST_PRIME_H_

int test_main(void);

#endif /* #ifndef __TEST_PRIME_H__ */
