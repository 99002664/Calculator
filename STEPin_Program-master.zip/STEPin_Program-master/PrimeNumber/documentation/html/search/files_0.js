var searchData=
[
  ['prime_2eh_2',['Prime.h',['../_prime_8h.html',1,'']]]
];
