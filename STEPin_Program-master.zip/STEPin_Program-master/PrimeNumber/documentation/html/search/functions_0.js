var searchData=
[
  ['prime_3',['prime',['../_prime_8h.html#a6104e9d3604cbaa3f874ecffbe4bc43d',1,'Prime.h']]]
];
