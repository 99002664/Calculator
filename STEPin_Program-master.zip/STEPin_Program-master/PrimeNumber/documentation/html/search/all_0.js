var searchData=
[
  ['prime_0',['prime',['../_prime_8h.html#a6104e9d3604cbaa3f874ecffbe4bc43d',1,'Prime.h']]],
  ['prime_2eh_1',['Prime.h',['../_prime_8h.html',1,'']]]
];
